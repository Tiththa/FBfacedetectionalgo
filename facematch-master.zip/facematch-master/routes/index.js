module.exports = {
  getAccessToken: require('./getAccessToken'),
  recognize: require('./recognize')
};